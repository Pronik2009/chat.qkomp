<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */
 
 //var_dump( is_home() );
 // var_dump(  is_front_page() );

get_header(); ?>
<style>
	.post-thumbnail img {display:block;width:100%;}
</style>

<div class="wrapper">
	<div class="row">
		<div class="col-xs-12">
			
		<?php if ( have_posts() ) :  ?>
			<h1 class="page-title text-center">Events list</h1>
			<hr />
			<?php	
			while ( have_posts() ) : 
					the_post();
					get_template_part( 'template-parts/post/content', /*get_post_format()*/ 'standart' );
					echo '<div class="col-md-12"><hr /></div>';
			endwhile;
		endif;
		?>
		
		</div>
	</div>
</div>

<?php get_footer();
