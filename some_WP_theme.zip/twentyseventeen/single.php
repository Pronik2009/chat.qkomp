<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); 
the_post();
?>
<style>
	.post-thumbnail img {display:block;width:100%;}
</style>

<div class="wrapper">
	<div class="row m" id="post-<?php the_ID(); ?>">

		<div class="col-sm-4">
			<?php if ( '' !== get_the_post_thumbnail() ) : ?>
				<div class="post-thumbnail"><?php the_post_thumbnail( 'twentyseventeen-featured-image' ); ?></div>
			<?php endif; ?>
		</div>
		<div class="col-sm-8">
			<a href="<?php the_permalink(); ?>"><h2><?php the_title() ?></h2></a>
			<?php the_content(); ?>
			<?php
				if ( IsEventActive($post->ID) ){ 
					echo '<a class="btn btn-success" href="'.get_site_url().'/poll1/?'.md5($post->ID).'">Visit ChatRoom</a>'; 
				}
			?>
		</div>
		<div class="col-sm-12" style="font-size:24px;"><hr /><a href="/"><i class="fa fa-arrow-left"></i> Home</a></div>
		
	</div>
</div>

<?php get_footer();
