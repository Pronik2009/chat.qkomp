<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/plugins/slick/slick.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/plugins/slick/slick-theme.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/animate.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/style.css" rel="stylesheet">

<link rel="profile" href="http://gmpg.org/xfn/11">

<?php //wp_head(); ?>
</head>

<body class="gray-bg" >
	<?php //get_template_part( 'template-parts/header/header', 'image' ); ?>

	<?php if ( has_nav_menu( 'top' ) ) : ?>
		<div class="navigation-top">
			<div class="wrap">
				<?php get_template_part( 'template-parts/navigation/navigation', 'top' ); ?>
			</div><!-- .wrap -->
		</div><!-- .navigation-top -->
	<?php endif; ?>

	<?php

	/*
	 * If a regular post or page, and not the front page, show the featured image.
	 * Using get_queried_object_id() here since the $post global may not be set before a call to the_post().
	 */

	?>

			<div class="row violet-bg border-bottom">
				<div class="col-lg-12 text-center"><h1 style="margin:10px auto;"><i class="fa fa-comments"></i> LiveChat</h1></div>
			</div>