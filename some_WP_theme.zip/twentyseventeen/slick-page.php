<?php
/*
Template Name: Slick
*/

//get_header(); 

include ('c4c/chat.php');
?>


<?php //get_footer();


