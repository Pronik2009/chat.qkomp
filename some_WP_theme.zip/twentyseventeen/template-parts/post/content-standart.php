<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */

?>

<div id="post-<?php the_ID(); ?>" class="col-md-12">
	<div class="row">
		<div class="col-sm-4">
			<?php if ( '' !== get_the_post_thumbnail() ) : ?>
				<div class="post-thumbnail"><?php the_post_thumbnail( 'twentyseventeen-featured-image' ); ?></div>
			<?php endif; ?>
		</div>
		<div class="col-sm-8">
			<a href="<?php the_permalink(); ?>"><h2><?php the_title() ?> <?php echo IsEventActive($post->ID) ? '<span class="label label-danger"><i class="fa fa-circle"></i> live now</span>' : '' ?> </h2></a>
			<?php the_content(); ?>
		</div>
	</div>
</div>
	
	
		<?php /*
		if ( 'post' === get_post_type() ) {
			echo '<div class="entry-meta">';
				if ( is_single() ) {
					twentyseventeen_posted_on();
				} else {
					echo twentyseventeen_time_link();
					twentyseventeen_edit_link();
				};
			echo '</div><!-- .entry-meta -->';
		};
		
		if ( is_single() ) {
			the_title( '<h1 class="entry-title">', '</h1>' );
		} elseif ( is_front_page() && is_home() ) {
			the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
		} else {
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		}  
		
		
		the_content( sprintf(
			__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'twentyseventeen' ),
			get_the_title()
		) );

		wp_link_pages( array(
			'before'      => '<div class="page-links">' . __( 'Pages:', 'twentyseventeen' ),
			'after'       => '</div>',
			'link_before' => '<span class="page-number">',
			'link_after'  => '</span>',
		) ); 
		*/