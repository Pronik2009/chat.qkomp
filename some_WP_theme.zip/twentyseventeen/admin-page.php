<?php
/*
Template Name: Admin
*/
wp_head(); 
get_header(); ?>
<?php if (is_user_logged_in()) { // если юзер залогинен, стандартная ф-я вп 
	$current_user = wp_get_current_user(); // получим данные о текущем залогиненом юзере ?>
<ol class="breadcrumb text-center">
  <li class="breadcrumb-item active m">
<p>Hi, <?php echo $current_user->display_name; ?>. <a href="#" class="logout" data-nonce="<?php echo wp_create_nonce('logout_me_nonce'); ?>">Logout</a></p> <!-- покажем приветствие и ссылку на выход, в атрибут data-nonce запишем строку для проверки безопасности -->
  </li>
</ol>
<?php include('c4c/admin.php'); } else { // если не залогинен, покажем форму для логина ?>
<style>
  input.form-control {color:black!important;}
</style>
<div class="container" style="margin-top:20px;">
<div class="row">
<div class="col-lg-6 col-md-12">
<div class="panel panel-info">
<div class="panel-heading">
<form name="loginform" id="loginform" method="post" class="userform m" action=""> <!-- обычная форма, по сути нам важен только класс -->
     <div class="form-group">
	<input class="form-control" type="login" name="log" id="user_login" placeholder="Login or email"> <!-- сюда будут писать логин или email -->
     </div>
     <div class="form-group">
	<input class="form-control" type="password" name="pwd" id="user_pass" placeholder="Password"> <!-- ну пароль -->
     </div>
	<!--<input name="rememberme" type="checkbox" value="forever"> Remember me  запомнить ли сессию, forever - навсегда,  -->
     <div class="form-group">
        <input type="submit" value="Login" class="btn btn-success"> <!-- субмит -->
     </div>
	<input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>"> <!-- куда отправим юзера если все прошло ок -->
	<input type="hidden" name="nonce" value="<?php echo wp_create_nonce('login_me_nonce'); ?>"> <!-- поле со строкой безопасности, будем проверим её в обработчике чтобы убедиться, что форма отправлена откуда надо, аргумент login_me_nonce, конечно, лучше поменять на свой -->
	<input type="hidden" name="action" value="login_me"> <!-- обязательное поле, по нему запустится нужная функция -->
	<div class="response"></div> <!-- ну сюда будем пихать ответ от сервера -->
</form>
</div></div></div></div></div>

<?php }; ?>
<?php get_footer();
