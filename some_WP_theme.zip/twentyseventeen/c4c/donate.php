<?php
require($_SERVER['DOCUMENT_ROOT'].'/wp-load.php');

if(isset($_GET[player])and isset($_GET[guest])and isset($_GET[amount])) {}
else {echo json_encode(array('error'=>'wrong request format'));die();}

$sql = "SELECT costs FROM wp_c4c_guests where name = '".$_GET[guest]."'";
global $wpdb;
$costs = $wpdb->get_var($sql);

if ($costs<$_GET[amount]) {echo json_encode(array('error'=>'not enough costs'));die();}

$sql = "UPDATE wp_c4c_guests SET costs=costs-".$_GET[amount]." WHERE name='".$_GET[guest]."'";
$result = $wpdb->query($sql);

$sql = "UPDATE wp_users SET user_url=user_url+".$_GET[amount]." WHERE display_name='".$_GET[player]."'";
$wpdb->query($sql);

echo json_encode(array('debet'=>$costs-$_GET[amount]));
?>