<?php

$ch = curl_init('https://us1.pusherplatform.io/services/chatkit_token_provider/v1/85c702df-adf4-4049-8b98-2937a3a106e0/token?user_id=Admin');
//$ch = curl_init('https://us1.pusherplatform.io/servuces/chatkit_authorizer/v1/85c702df-adf4-4049-8b98-2937a3a106e0/token?user_id=Admin');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array('user_id'=>'Admin','grant_type '=>'admin_credentials')));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // флаг о том, что нужно получить результат
    //$resp = json_decode(curl_exec($ch)); // отправляем запрос
    curl_close($ch); // закрываем соединение
//var_dump($resp->access_token);
//echo '<br /><br /><br />';
/*
{
  "instance": "85c702df-adf4-4049-8b98-2937a3a106e0",
  "iss": "api_keys/59f2caf6-4112-4e68-9484-cbe78a882e48",
  "iat": 1525561200,
  "exp": 1525647600,
  "sub": "Admin",
  "su" : true
}
*/
$su_token = require('jwt_sign_creator.php');
//echo $su_token.'<br />';  
//$su_token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpbnN0YW5jZSI6Ijg1YzcwMmRmLWFkZjQtNDA0OS04Yjk4LTI5MzdhM2ExMDZlMCIsImlzcyI6ImFwaV9rZXlzLzU5ZjJjYWY2LTQxMTItNGU2OC05NDg0LWNiZTc4YTg4MmU0OCIsImlhdCI6MTUyNTU2MTIwMCwiZXhwIjoxNTI1NjQ3NjAwLCJzdWIiOiJBZG1pbiIsInN1Ijp0cnVlfQ.AcHpJHWhtJvLf1cMIrCJLuVaMm5oJ6nLRzC0pl-wiec';
$token ='Authorization: Bearer '.$su_token;

$resp = WEB_TO_API('chatkit','/users?from_ts=2018-05-10T14:02:00Z', 'get', array(), $token);
var_dump($resp);die();

$resp = WEB_TO_API('chatkit','/users/uid_75', 'delete', array(), $token);
var_dump($resp);die();

$resp = WEB_TO_API('chatkit','/users/vasya/rooms/7416719/join', 'post', array(), $token);
var_dump($resp);die();


?>
<!DOCTYPE html>
<head>
  <title>Pusher ChatKit Test</title>

<!--ChatKit-->
<script src="https://unpkg.com/@pusher/chatkit@0.7.5/dist/web/chatkit.js"></script>
<script>
let chat = {
    messages: [],
    room:  undefined,
    userId: undefined,
    currentUser: undefined,
};
const tokenProvider = new Chatkit.TokenProvider({
  url: "https://us1.pusherplatform.io/services/chatkit_token_provider/v1/85c702df-adf4-4049-8b98-2937a3a106e0/token"
});

const chatManager = new Chatkit.ChatManager({
  instanceLocator: "v1:us1:85c702df-adf4-4049-8b98-2937a3a106e0",
  userId: "Admin",
  tokenProvider: tokenProvider
});

chatManager
  .connect()
  .then(currentUser => {
      console.log(currentUser.rooms); 
      
  })
/*  
currentUser.createRoom({
  name: 'general',
  private: false,
  addUserIds: []
   }).then(room => {
  console.log(`Created room called ${room.name}`)
      })
.catch(err => {
  console.log(`Error creating room ${err}`)
});
*/
    .catch(error => {
    console.error("error:", error);
  });
  
/*
chatManager
  .connect()
  .then(currentUser => {
      currentUser.subscribeToRoom({
        roomId: currentUser.rooms[0].id,
        hooks: {
          onNewMessage: message => {
            console.log(`Received new message: ${message.text}`)
          }
        }
      });
    })
  .catch(error => {
    console.error("error:", error);
  });
*/  
  
</script>

</head>
<body>

<ul id="message-list" style="overflow-y: scroll;height:150px;width:300px;border:solid;"></ul>
    <form id="message-form">
      <input type='text' id='message-text'>
      <input type="submit">
    </form>

<script>
chatManager
.connect()
.then(currentUser => {
  currentUser.subscribeToRoom({
    roomId: currentUser.rooms[0].id,
    hooks: {
      onNewMessage: message => {
        const ul = document.getElementById("message-list");
        const li = document.createElement("li");
        li.appendChild(
          document.createTextNode(`${message.senderId}: ${message.text}`)
        );
        ul.appendChild(li);
      }
    }
  });

  const form = document.getElementById("message-form");
  form.addEventListener("submit", e => {
    e.preventDefault();
    const input = document.getElementById("message-text");
    currentUser.sendMessage({
      text: input.value,
      roomId: currentUser.rooms[0].id
    });
    input.value = "";
  });
})
.catch(error => {
  console.error("error:", error);
});
</script>    
</body>
</html>
