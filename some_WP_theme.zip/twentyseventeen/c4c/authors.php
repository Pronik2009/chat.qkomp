<?php
require($_SERVER['DOCUMENT_ROOT'].'/wp-load.php');

global $wpdb;
$sql = "SELECT u.id, u.display_name as name, (SELECT guid FROM wp_posts WHERE ID = (SELECT meta_value FROM wp_usermeta where user_id=u.ID and meta_key='wp_metronet_image_id')) as avatar, u.user_status as isLive, (SELECT meta_value FROM wp_usermeta WHERE meta_key='description' and user_id=u.ID) as info FROM wp_usermeta um INNER JOIN wp_users u ON um.user_id = u.id and um.meta_key='wp_capabilities' and um.meta_value like '%author%'";
$players = $wpdb->get_results($sql, ARRAY_A);

$array4json = array();
foreach ($players as $author) {
	if (!isset($author[avatar])) {$author[avatar] = get_site_url().'/wp-content/plugins/metronet-profile-picture/img/mystery.png';	};
	$array4json[$author[id]] = array('id'=>$author[id],'name'=>$author[name],'avatar'=>$author[avatar],'isLive'=>$author[isLive],'info'=>$author[info]);
	//print_r($author[id]);echo '<br />';
};
echo json_encode($array4json);
?>