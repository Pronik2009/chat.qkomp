<?php 
require($_SERVER['DOCUMENT_ROOT'].'/wp-load.php');

//Deleting selected guest
  if ( !empty($_GET[user_id]) && !empty($_GET[action]) && ($_GET[action]=="userDelete")) {
    del_guest($_GET[user_id]);
  };
  function del_guest($guest) {
    global $wpdb;
    $sql = "UPDATE wp_c4c_guests SET session_id=0 WHERE id = ".$guest ;
    $wpdb->query($sql);
//Deleting from ChatKit
    $su_token = require('jwt_sign_creator.php');
    $token ='Authorization: Bearer '.$su_token;
    $resp = WEB_TO_API('chatkit','/users/uid_'.$guest, 'delete', array(), $token); 
	die();
  };  

//Get debet for selected guest
  if ( !empty($_GET[user_id]) && !empty($_GET[action]) && ($_GET[action]=="getDebt")) {
    debt_guest($_GET[user_id]);
  };
  function debt_guest($guest) {
    global $wpdb;
    $sql = "SELECT costs FROM wp_c4c_guests WHERE id = ".$guest ;
    $debt = $wpdb->get_var($sql);
	echo (!is_null($debt)) ? json_encode(array("code"=>1,"text"=>$debt)) : json_encode(array("code"=>0,"text"=>"user not found"));
	die();
  };  

//Send money (Donation to authors)
  if ( !empty($_GET[author_id]) && !empty($_GET[user_id]) && !empty($_GET[amount]) && ($_GET[action]=="sendMoney")) {
    donation($_GET[author_id],$_GET[user_id],$_GET[amount]);
  } else {echo json_encode(array('text'=>'wrong request format','code'=>0));die();};
  function donation($author,$guest,$amount) {
	global $wpdb;
	$sql = "SELECT costs FROM wp_c4c_guests where id = ".$guest;
	$costs = $wpdb->get_var($sql);

	if ($costs<$amount) {echo json_encode(array('text'=>'not enough costs','code'=>0));die();}

	$sql = "UPDATE wp_c4c_guests SET costs=costs-".$amount." WHERE id=".$guest;
	$wpdb->query($sql);

	$sql = "UPDATE wp_users SET user_url=user_url+".$amount." WHERE id=".$author;
	$wpdb->query($sql);

	echo json_encode(array('text'=>$costs-$amount,'code'=>1));
	die();
  };