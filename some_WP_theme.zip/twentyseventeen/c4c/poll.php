	
	<div class="row wrapper border-bottom white-bg page-heading hidden-xs">
		<div class="col-lg-12">
			<h2>Event Name - Chat</h2>
			<ol class="breadcrumb">
				<li><a href="/">Home</a></li>
				<li><a href="/">Event Name</a></li>
				<li class="active"><strong>Chat</strong></li>
			</ol>
		</div>
	</div>
	
	<div class="wrapper wrapper1-content animated fadeInRight" style="padding:0;">
		<div class="row">
			<div class="col-lg-8 col-lg-offset-2 col-md-6 col-md-offset-3 col-sm-12 col-xs-12">
				<div class="ibox chat-view">
					<div class="text-center m"><strong>Chat room info</strong> can added here. Some rules or other important info.</div>
					<div class="ibox-title">
						<div class="pull-right">
							Your deposit: 
							<strong class="text-danger" id="money_block">$<span class="money-total">0</span></strong>
							<span id="money_block_loading" class="hidden"><i class="fa fa-refresh fa-spin"></i> <span class="sr-only">Loading...</span></span></div>
						<i class="fa fa-user"></i> <strong id="current_user_name">Username</strong> <a href="#" id="user_logout_btn" class="btn btn-xs btn-danger btn-outline hidden"><i class="fa fa-sign-out"></i> Logout</a>
					</div>
					<div class="ibox-content">
						
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="chat-discussion" id="chat_window"></div>
							</div>
						</div>
						<hr />
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<ul class="authors-slider text-center"></ul>
								<div class="clearfix"></div>
								<div id="autor_info" class="autor_info m-xs">
									<a href="#" class="btn btn-success btn-xs btn-close pull-right">x</a>
									<div class="alert alert-info alert-dismissable"><div></div></div>
									<div class="donate-block">
										<strong>Donate <span></span>:</strong>
										<div class="btn-group" role="group" aria-label="..." id="donate_buttons">
											<button type="button" class="btn btn-default" data-value="1">$1</button>
											<button type="button" class="btn" data-value="5">$5</button>
											<button type="button" class="btn btn-info" data-value="10">$10</button>
											<button type="button" class="btn btn-success" data-value="15">$15</button>
											<button type="button" class="btn btn-success" data-value="20">$20</button>
											<button type="button" class="btn btn-warning" data-value="25">$25</button>
											<button type="button" class="btn btn-danger btn-total" data-value="0">all the money!</button>
										</div>
										<div class="sending-message hidden">Sending...</div>
										<div><small><b>$<span id="money_total" class="money-total">0</span></b> left</small></div>
									</div>
								</div>
							</div>
						</div>
						
					</div>
					<form class="ibox-footer" id="form-msg-sender">
						<div class="input-group input-group-sm">
							<input type="text" name="message" class="form-control" placeholder="Enter message here..." />
							<span class="input-group-btn"> <button class="btn btn-primary" type="submit">Send <i class="fa fa-paper-plane" aria-hidden="true"></i></button> </span>
						</div>
					</form>
					
				</div>
			</div>
		</div>	
	</div>

	<!--  FOOTER -->
	<div class="violet-bg">
		<div class="p-xs">LiveChat &copy; 2018</div>
	</div>

	<!-- Mainly scripts -->
	<script src="<?php echo get_template_directory_uri(); ?>/c4c/js/jquery-2.1.1.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/c4c/js/bootstrap.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/c4c/js/jquery.cookie.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/c4c/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/c4c/js/plugins/slick/slick.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="https://unpkg.com/@pusher/chatkit@0.7.5/dist/web/chatkit.js"></script>

	<script>
		var currentUser = {
			uid: <?php echo !empty($guest_id) ? (int)$guest_id : 0; ?>,
			ckData : {id:'<?php echo 'uid_'.$guest_id; ?>', name:'<?php echo $guest_name; ?>'},
			eventId: '<?php echo !empty($event_id) ? $event_id : ''; ?>', 
			roomId: <?php echo !empty($room_id) ? $room_id : 0; ?>, 
			roomNum: 0,
			money: <?php echo !empty($guest_amount) ? (int)$guest_amount : 0; ?>,
		};
		var authors = {};
		var currentAuthor = {};
		const tokenProvider = new Chatkit.TokenProvider({ url: "https://us1.pusherplatform.io/services/chatkit_token_provider/v1/85c702df-adf4-4049-8b98-2937a3a106e0/token" });
		const chatManager = new Chatkit.ChatManager({
		  instanceLocator: "v1:us1:85c702df-adf4-4049-8b98-2937a3a106e0",
		  userId: currentUser.ckData.id,
		  tokenProvider: tokenProvider
		});

        $(document).ready(function(){
			
			let authorsSliderItems;
			const chatWindow = $('#chat_window');
			const userLogoutBtn = $('#user_logout_btn');
			const userMoneyBlock = $('#money_block');
			const userMoneyBlockLoading = $('#money_block_loading');
			const authorsInfoBlock = $('#autor_info');
			const authorsInfoBlockCloseBtn = authorsInfoBlock.find('a.btn-close');
			const donationBtnsBlock = $('#donate_buttons');
			const donationSendingMessageBlock = $('.sending-message');
			//const donationUrl = '<?php echo get_template_directory_uri().'/c4c/donate.php'; ?>';
			const authorsUrl = '<?php echo get_template_directory_uri().'/c4c/authors.php'; ?>';
			const userDataUrl = '<?php echo get_template_directory_uri().'/c4c/user.php'; ?>';
			const authorsSlider = $('.authors-slider');
			const formMessageSender = $("#form-msg-sender");
			const formMessageSenderInput = formMessageSender.find('input');
			const authorsSliderParams = {
				infinite: false, arrows: false, slidesToShow: 6, slidesToScroll: 2, /* adaptiveHeight: true, */
				responsive: [
					{ breakpoint: 740, settings: { arrows: false, slidesToShow: 6, slidesToScroll: 2 } },
					{ breakpoint: 520, settings: { arrows: false, slidesToShow: 4, slidesToScroll: 2 } }
				]
            }; 
			const swalTitle = '';
			
			function userCookieNameRemove( name ){
				return $.removeCookie(name);
			}
			function userLogout(){
				swal({
				  title: "Are you sure?", text: "Once logout, you will not be able to save deposit money!", icon: "warning", dangerMode: true,
				  buttons: {
					cancel: { text: "No! Just kidding :)", value:false, visible: true, closeModal: true, },
					confirm: { text: "Yes, logout me", value: true, visible: true, closeModal: false },
				  },
				})
				.then(isLogout => {
				  if ( isLogout ) {
					currentUser.ckData.roomSubscriptions[currentUser.roomId].cancel();
					$.ajax({
						url: userDataUrl, dataType: 'json', data: {'user_id':currentUser.uid,'action':'userDelete'}, 
						success: function(jsondata) { console.log('user data delete from DB'); }
					});
					userCookieNameRemove( 'uid' );
					userCookieNameRemove( 'room_id' );
					userCookieNameRemove( 'event_'+currentUser.eventId );
					currentUser = {}; 
					chatWindow.hide();
					swal('Good Bye!', 'success'); 
					location.reload(); 
				  }
				});
				return false;
			}
			
			function userMoneyGetProcess( type ){
				if ( type === 'start' ){
					userMoneyBlockLoading.removeClass('hidden');
					userMoneyBlock.addClass('hidden');
					return true;
				}
				if ( type === 'end' ){
					userMoneyBlockLoading.addClass('hidden');
					userMoneyBlock.removeClass('hidden');
					return true;
				}
				return false;
			}
			function sleep(ms) {
			  return new Promise(resolve => setTimeout(resolve, ms));
			}
			async function userMoneyGet(){
				userMoneyGetProcess( 'start' );
				await sleep(2000);
				
				$.ajax({
					url: userDataUrl,
					dataType: 'json',
					data: {'user_id':currentUser.uid,'action':'getDebt'},
					success: function(jsondata) {
					  if ( jsondata.code ) {
						currentUser.money = parseInt( jsondata.text );
						userMoneyRender();
					  }
					  userMoneyGetProcess( 'end' );
					}
				});
				
				userMoneyGetProcess( 'end' );
			}
			function userMoneyGetByTimer() { 
				userMoneyGet();
				setTimeout(userMoneyGetByTimer, 10000);  console.log( 'userMoneyGet run by timer' ); /* */
			}
			function userMoneyRender(){
				$('.money-total').empty().text( currentUser.money );
				donationBtnsBlock.find('.btn-total').attr('data-value', currentUser.money);
				return false;
			}
			function userNameRender(){
				$('#current_user_name').empty().text( currentUser.ckData.name );
				return false;
			}
			function userDataRender(){
				userMoneyRender();
				userNameRender();
				userLogoutBtn.removeClass('hidden');
				return false;
			}
			function authorsDataGet(){
				$.ajax({
					url: authorsUrl,
					dataType: 'json',
					success: function(jsondata) {
						if ( authors != jsondata ){
							authors = jsondata; 
							authorsDataRender(); 
						}
					}
				});
				return false;
			}
			function authorsDataGetByTimer() { 
				authorsDataGet();
				setTimeout(authorsDataGetByTimer, 10000);  console.log( 'authorsDataGet run by timer' ); /* */
			}
			function authorsDataRender(){
				if ( $.isEmptyObject(authors) ){ return false; }
				authorsSlider.slick('unslick');
				var str = '';
				var liveClass = '';
				$.each(authors, function(i, item) {
					liveClass = ( item.isLive == '0' ) ? ' hidden' : '';
					str += '<li data-aid="'+item.id+'">'
								+'<span class="label label-danger'+liveClass+'"><i class="fa fa-circle"></i> live now</span>'
								+'<img class="img-responsive" src="'+item.avatar+'" alt="" />'
								+'<strong class="author-name">'+item.name+'</strong>'
								+'<p><strong>'+item.name+' <span class="label label-danger'+liveClass+'"><i class="fa fa-circle"></i> live now</span></strong><br />'+item.info+'</p>'
							+'</li>';
				});
				authorsSlider.empty().html( str );
				authorsSlider.slick( authorsSliderParams );
				authorsSliderItems = authorsSlider.find('li');
				authorsSliderItems.on('click', authorsInfoShow);
				return false;
			}
			function messageRender( item ){
				var str = '<div class="chat-message '+item.mClass+'">'
									+'<div class="message">'
										+'<span class="message-author">'+item.userName+'</span>'
										+'<span class="message-date">'+item.createdAt+'</span>'
										+'<span class="message-content">'+item.message+'</span>'
									+'</div>'
								+'</div>';
				chatWindow.append( str );
				chatWindow.scrollTop(chatWindow.prop('scrollHeight'));
				return false;
			}
			function messagesInit(){
				chatWindow.empty();
			}
			function authorsInfoShow(){
				var item = $(this);
				currentAuthor = authors[ item.attr('data-aid') ];
				authorsInfoBlock.find('.alert').find('div').empty().html( item.find('p').html() );
				authorsInfoBlock.find('.donate-block').find('strong').find('span').empty().text( item.find('.author-name').text() );
				authorsInfoBlock.slideDown();
				authorsSliderItems.removeClass('active');
				item.addClass('active');
				return false;
			}
			function authorsInfoHide(){
				currentAuthor = {};
				authorsInfoBlock.find('.alert').find('div').empty();
				authorsInfoBlock.find('.donate-block').find('strong').find('span').empty();
				authorsInfoBlock.slideUp();
				authorsSliderItems.removeClass('active');
				return false;
			}
			function sendUserMessage() {
			  currentUser.ckData.sendMessage({
				text: currentUser.ckData.name+'|'+formMessageSenderInput.val(),
				roomId: currentUser.roomId
			  });
			  formMessageSenderInput.val('');
			  return false;
			}
			function sendUserDonationProcess( type ){
				if ( type === 'start' ){
					donationSendingMessageBlock.removeClass('hidden');
					donationBtnsBlock.addClass('hidden');
					return true;
				}
				if ( type === 'end' ){
					donationSendingMessageBlock.addClass('hidden');
					donationBtnsBlock.removeClass('hidden');
					return true;
				}
				return false;
			}
			function sendUserDonation() {
				if ( currentAuthor === undefined ){ return false; }
				var money = parseInt( $(this).attr('data-value') );
				if ( ! money ){ swal(swalTitle, 'You do not have any money left!', 'error'); return false;}
				if ( ! currentUser.money ){ swal(swalTitle, 'You do not have money!', 'error'); return false;}
				if ( money > currentUser.money ){ swal(swalTitle, 'You do not have enough money!', 'error'); return false;}
				sendUserDonationProcess( 'start' );
				$.ajax({
					url: userDataUrl,
					dataType: 'json',
					data: {'author_id':currentAuthor.id,'user_id':currentUser.uid,'amount':money,'action':'sendMoney'},
					success: function(jsondata) {
					  if ( jsondata.code ) {
						currentUser.money = parseInt( jsondata.text );
						userMoneyRender();
						swal('Money sended!', '$'+currentUser.money+' left', 'success');
						currentUser.ckData.sendMessage({ 
							text: 'money|<b>$'+money+'</b> donation to <b>'+currentAuthor.name+'</b>!', 
							roomId: currentUser.roomId
						});
					  } else {
						swal(swalTitle,  jsondata.text, 'error' );
					  }
					  sendUserDonationProcess( 'end' );
					}
				});
				return false;
			}
			
			userLogoutBtn.on('click',userLogout);
			donationBtnsBlock.find('button').on('click',sendUserDonation);
			authorsInfoBlockCloseBtn.on('click',authorsInfoHide);
			formMessageSender.on('submit',function(event){event.preventDefault();sendUserMessage();}); 
			
			/** final summary chat init **/
			function chatInit(){
				userDataRender();
				messagesInit();
				authorsInfoBlock.slideUp();
				authorsSlider.slick( authorsSliderParams );
				authorsDataGet();
				setTimeout( authorsDataGetByTimer, 10000 );
				setTimeout( userMoneyGetByTimer, 1000 );
			}
			
			/* --------------------------- CHAT INIT ------------------------------ */
			chatInit();
			
			chatManager
				.connect()
				.then(curUser => {
					currentUser.ckData = curUser;
					//Check for room_id 
					for (i=0;i<curUser.rooms.length;i++) {
					  if(curUser.rooms[i].id==currentUser.roomId){currentUser.roomNum=i;break;}; 
					};
					//Message listener  
					curUser.subscribeToRoom({
					  roomId: currentUser.roomId,
					  hooks: {
						onNewMessage: message => {
							var msg = message.text.split('|',2);
							var liclass = '';
							switch (msg[0]) {
								case 'money' : message.text = msg[1]; liclass='money'; break;
								case curUser.name : message.text = msg[1]; liclass='right'; break;
								default : message.text = msg[1]; liclass='left'; break;
							};
							message.mClass=liclass;
							message.message=message.text;
							try{ message.userName = message.sender.name; }catch(e){ message.userName = '<i>** deleted **</i>'; }
							messageRender(message);
						}
					  }
					});
				  })
				.catch(error => { console.log(error); swal(swalTitle,  'Chat connection error! Please, reload page.', 'error' ); $('.chat-view').remove(); });
});
</script>

</body>
</html>
