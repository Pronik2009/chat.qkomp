<div class="container"><div class="row">
<div class="col-lg-6 col-md-12 m">
<div class="panel panel-info"><div class="panel-heading">

<p>Enter your NickName:</p>

<form name="nameform1" id="nameform1" method="post" class="1__userform" action="<?php the_permalink(); ?>"> <!-- обычная форма, по сути нам важен только класс -->
     <div class="input-group">
	<input style="color: black;" type="text" name="guest_name" id="guest_name" class="form-control" placeholder="Enter your name here"> <!-- сюда будут писать логин или email -->
     <span class="input-group-btn">	
	<button class="btn btn-success" type="submit" value="Login">Log in</button><!-- субмит -->
     </span>
     </div>
	<input type="hidden" name="action" value="reg_this_guest"> <!-- обязательное поле, по нему запустится нужная функция -->
	<input type="hidden" name="event_url" value="<?php echo $_SERVER[QUERY_STRING]; ?>"> <!-- обязательное поле, по нему запустится нужная функция -->    
</form>
<?php //exit ?>

</div></div></div></div></div>

	<!--  FOOTER -->
	<div class="violet-bg" style="position:absolute;bottom:0;width:100%;">
		<div class="p-xs">LiveChat &copy; 2018</div>
	</div>

	<!-- Mainly scripts -->
	<script src="<?php echo get_template_directory_uri(); ?>/c4c/js/jquery-2.1.1.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/c4c/js/bootstrap.min.js"></script>
</body>
</html>
