<!--POST processing-->
<?php
function c4c_get_table_handle($tablename) {
    //объявить встроенную в WP переменную - дескриптор БД блога
    global $wpdb;
    //вернуть дескриптор таблицы настроек плагина, расположенной в БД WP-блога
    return $wpdb->prefix . "c4c_".$tablename;
}

  //Setting costs to guests
  if (isset($_POST[Submit])and isset($_POST[guests])and isset($_POST[cmd])and($_POST[cmd]=="c4c_cost_adding")) {
    $c4c_prefs_table = c4c_get_table_handle('guests');
    foreach ($_POST[guests] as $guest) {
      add_amount2guest($guest,$_POST[Costs]);
    };
  };

  function add_amount2guest($guest_id,$amount) {
    global $wpdb,$c4c_prefs_table;
    $sql = "UPDATE ".$c4c_prefs_table." SET costs=costs+".$amount." WHERE id=".$guest_id;
    $wpdb->query($sql); 
  };  

  //Deleting selected guests
  if (isset($_POST[SubmitDel])and isset($_POST[guests])and isset($_POST[cmd])and($_POST[cmd]=="c4c_cost_adding")) {
    $c4c_prefs_table = c4c_get_table_handle('guests');
    del_guest($_POST[guests]);
  };

  function del_guest($guests) {
    global $wpdb,$c4c_prefs_table;
    $sql = "DELETE FROM ".$c4c_prefs_table." WHERE id in (".implode(',',$guests).")";
    $wpdb->query($sql); 
	//Deleting from ChatKit
    $su_token = require('jwt_sign_creator.php');
    $token ='Authorization: Bearer '.$su_token;
    foreach ($guests as $guest) {
	  $resp = WEB_TO_API('chatkit','/users/uid_'.$guest, 'delete', array(), $token); 
	  // print_r($resp);die();
    };
  };  

  //Setting costs to players
  if (isset($_POST[Submit]) and isset($_POST[players])and isset($_POST[cmd])and($_POST[cmd]=="c4c_players_cost_set")) {
  $c4c_prefs_table = 'wp_users';
   foreach ($_POST[players] as $player) {
    add_amount2player($player,$_POST[Costs]);
   };
  };

  function add_amount2player($player_id,$amount) {
    global $wpdb,$c4c_prefs_table;
    $sql = "UPDATE ".$c4c_prefs_table." SET user_url=".$amount." WHERE id=".$player_id;
    $wpdb->query($sql); 
  };

  //Setting Live status to players
  if (isset($_POST[SubmitLive])and isset($_POST[cmd])and($_POST[cmd]=="c4c_players_cost_set")) {
  $c4c_prefs_table = 'wp_users';
   $live_id = $_POST[live][0];
   set_status2player($live_id);
  };

  function set_status2player($live_id) {
    global $wpdb,$c4c_prefs_table;
//Nulling all players statuses
    $sql = "UPDATE ".$c4c_prefs_table." SET user_status=0 WHERE ID IN (SELECT um.user_id FROM wp_usermeta um WHERE um.meta_key='wp_capabilities' and um.meta_value like '%author%')";
    $wpdb->query($sql);
//Setting selected player status
    $sql = "UPDATE ".$c4c_prefs_table." SET user_status=1 WHERE id=".$live_id;
    $wpdb->query($sql); 
  };

  //Setting active to events
  if (isset($_POST[events])and isset($_POST[cmd])and($_POST[cmd]=="c4c_events_status_set")) {
  $c4c_prefs_table = 'wp_posts';
   $event_id=$_POST[events][0];
   set_status2event($event_id);
   //};
  };

  function set_status2event($event_id) {
    global $wpdb,$c4c_prefs_table;
    $sql = "UPDATE ".$c4c_prefs_table." SET ping_status='closed' WHERE post_status = 'publish' and post_type='post'";
    $wpdb->query($sql);
    $sql = "UPDATE ".$c4c_prefs_table." SET ping_status='open' WHERE post_status = 'publish' and post_type='post' and id=".$event_id;
    $wpdb->query($sql); 
    $su_token = require('jwt_sign_creator.php');
    $token ='Authorization: Bearer '.$su_token;
//Delete all rooms on ChatKit
    $resp = WEB_TO_API('chatkit','/users/Admin/rooms', 'get', array(), $token);
    foreach($resp as $room){
      $resp1 = WEB_TO_API('chatkit','/rooms/'.$room->id, 'delete', array(), $token); 
    };
//Create new Room on ChatKit
    $resp = WEB_TO_API('chatkit','/rooms', 'post', json_encode(array("name"=>"event_".$event_id,"private"=>false)), $token);
  };  
?>  
<!--End of POST processing-->
<script src="https://unpkg.com/@pusher/chatkit@0.7.5/dist/web/chatkit.js"></script>
<script language="JavaScript">

function toggle(source,elements_name) {
  checkboxes = document.getElementsByName(elements_name);
  for(var i=0, n=checkboxes.length;i<n;i++) {
    checkboxes[i].checked = source.checked;
  }
};
const tokenProvider = new Chatkit.TokenProvider({
  url: "https://us1.pusherplatform.io/services/chatkit_token_provider/v1/85c702df-adf4-4049-8b98-2937a3a106e0/token"
});

  const chatManager = new Chatkit.ChatManager({
  instanceLocator: "v1:us1:85c702df-adf4-4049-8b98-2937a3a106e0",
  userId: "Admin",
  tokenProvider: tokenProvider
});

</script>

<div class="container"> 
<div class="row">
<!--Заголовок блока событий-->
<div class="col-lg-6 col-md-12">
<div class="panel panel-primary">
  <div class="panel-heading">Events list</div>
  <div class="panel-body">
  <form method="post" action="<? echo $_SERVER['REQUEST_URI'];?>" id="EventSetActive">
  <table class="table table-striped table-borderless table-hover">
    <thead class="table-danger">
    <td></td><td>Event ID</td><td>Event Name</td><td>Is active?</td><td>ChatRoom</td>
    </thead>
<?php 
    $sql = "SELECT * FROM wp_posts WHERE post_status = 'publish' and post_type='post'";
    $events = $wpdb->get_results($sql, ARRAY_A);
    foreach ($events as $event) { 
	//print_r($event);die();
	?>
    <tr>
    <td><input <?php if($event[ping_status]=='open'){echo 'checked';}; ?> type="radio" class="EventRadio" name="events[]" value="<?php echo $event[ID] ?>" /></td>
    <td><?php echo $event[ID]; ?></td>
    <td><a href="<?php echo site_url().'/'.$event[post_name]; ?>"><?php echo $event[post_title]; ?></a></td>
    <td><?php echo $event[ping_status]; ?></td>
    <td><a href=<?php echo site_url(); ?>/poll?<?php echo md5($event[ID]); ?>>Here</a></td>
    </tr>
    <?php }; ?>
  </table>
    <input type="hidden" name="cmd" value="c4c_events_status_set">
    <span class="submit">
    <button class="btn btn-success" type="submit" name="Submit"><?php _e('Set active') ?></button>
    </span>
  </form>
  </div>
</div>
<!-- </div> -->
<!--Конец блока событий-->

<!--Заголовок блока гостей-->

<!-- <div class="col-lg-6 col-md-12"> -->
<div class="panel panel-success">
  <div class="panel-heading">Guest list</div>
  <div class="panel-body">

    <form method="post" action="<? echo $_SERVER['REQUEST_URI'];?>">
    <div class="form-table">
      <table class="table table-striped table-borderless table-hover">
      <thead class="table-success">
      <td><input type="checkbox" onClick="toggle(this,'guests[]')" /></td>
      <td>ID</td><td>Event</td><td>Guest Name</td><td>Online</td><td>Costs amount</td>
      </thead>
<?php 
    $c4c_prefs_table = c4c_get_table_handle('guests');
    $sql = "SELECT g.*, p.post_title,p.post_name FROM ".$c4c_prefs_table." g INNER JOIN wp_posts p ON g.event_id=p.ID";
    $guests = $wpdb->get_results($sql, ARRAY_A);
    foreach ($guests as $guest) { ?>
      <tr>
      <td><input type="checkbox" name="guests[]" value="<?php echo $guest[id] ?>" /></td>
      <td><?php echo $guest[id]; ?></td>
      <td><a href="<?php echo site_url().'/'.$guest[post_name]; ?>"><?php echo $guest[post_title]; ?></a></td>
      <td><?php echo $guest[name]; ?></td>
      <td class="text-center"><?php echo ($guest[session_id]!="0") ? "<i class='fa fa-circle text-info'></i>" : "<i class='fa fa-circle text-danger'></i>" ?></td>
      <td class="text-center"><?php echo $guest[costs]; ?></td>
      </tr>
    <?php }; ?>
      </table>
      <input type="hidden" name="cmd" value="c4c_cost_adding">
      <div class="input-group">
        <input type="number" name="Costs" placeholder="some amount" class="form-control" />
		<span class="input-group-btn">
        <button class="btn btn-success" type="submit" name="Submit"><?php _e('Add $') ?></button>
		</span>
        <button class="btn btn-danger btn_live" type="submit" name="SubmitDel"><?php _e('Delete selected') ?></button>
      </div>
    </div>
    </form>
  </div>
</div>
</div>   
<!--Конец заголовка блока гостей-->

<!--Заголовок блока участников-->
<div class="col-lg-6 col-md-12">
<div class="panel panel-info">
  <div class="panel-heading">Players list</div>
  <div class="panel-body">
  <form method="post" action="<? echo $_SERVER['REQUEST_URI'];?>">
  <table class="table table-striped table-borderless table-hover">
    <thead class="table-danger">
    <td><input type="checkbox" onClick="toggle(this,'players[]')" /></td><td>Player ID</td><td>Player Name</td><td>Costs amount</td><td>On air</td>
    </thead>
<?php 
    $sql = "SELECT * FROM wp_usermeta um INNER JOIN wp_users u ON um.user_id = u.id and um.meta_key='wp_capabilities' and um.meta_value like '%author%'";
    $players = $wpdb->get_results($sql, ARRAY_A);
    foreach ($players as $player) { ?>
    <tr>
    <td><input type="checkbox" name="players[]" value="<?php echo $player[ID] ?>" /></td>
    <td><?php echo $player[ID]; ?></td>
    <td><?php echo $player[display_name]; ?></td>
    <td><?php echo str_replace('http://','',$player[user_url]); ?></td>
	<td><input <?php if($player[user_status]==1){echo 'checked';}; ?> type="radio" name="live[]" value="<?php echo $player[ID] ?>" /></td>
    </tr>
    <?php }; ?>
  </table>
    <input type="hidden" name="cmd" value="c4c_players_cost_set">
    <div class="input-group">
    <input type="number" name="Costs" placeholder="some amount" step="5" class="form-control" />
    <span class="input-group-btn">
	<button class="btn btn-success" type="submit" name="Submit"><?php _e('Set $') ?></button>
    </span>
    <button class="btn btn-danger btn_live" type="submit" name="SubmitLive"><?php _e('Set live') ?></button>
    </div>
  </form>
  </div>
</div>
</div>
<!--Конец заголовка блока участников-->
</div>    
</div>

<script>
chatManager
.connect()
.then(currentUser => {
  const form = document.getElementById("EventSetActive");
  form.addEventListener("submit", e => {
    //e.preventDefault();
//console.log(currentUser.rooms);
    let event_id = '';
    const radio = document.getElementsByClassName("EventRadio");
    [].forEach.call(radio, function (el) {
      if (el.checked) {
        event_id = 'event_'+el.value;
      };
    });  
    //проверяем, есть ли нужная комната в ChatKit
    let NeedCreateRoom = false;
    [].forEach.call(currentUser.rooms, function (el) {
      if (el.name == event_id) NeedCreateRoom = true;
    });
    if(NeedCreateRoom) {
        //console.log ('FOUND!');
    } else {
      //создаем её в ChatKit
      currentUser.createRoom({
        name: event_id,
        private: false,
        addUserIds: []
        }).then(room => {
        console.log(`Created room called ${room.name}`)
        })
      .catch(err => {
        console.log(`Error creating room ${err}`)
      });
    };
  });
})
.catch(error => {
  console.error("error:", error);
});
</script>