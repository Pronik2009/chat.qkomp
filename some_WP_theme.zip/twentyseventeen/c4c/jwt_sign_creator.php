<?php
/* //Payload for SuToken (JWT.io)
{
  "instance": "85c702df-adf4-4049-8b98-2937a3a106e0",
  "iss": "api_keys/59f2caf6-4112-4e68-9484-cbe78a882e48",
  "iat": 1525561200,
  "exp": 1525647600,
  "sub": "Admin",
  "su" : true
}
*/
//$su_token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpbnN0YW5jZSI6Ijg1YzcwMmRmLWFkZjQtNDA0OS04Yjk4LTI5MzdhM2ExMDZlMCIsImlzcyI6ImFwaV9rZXlzLzU5ZjJjYWY2LTQxMTItNGU2OC05NDg0LWNiZTc4YTg4MmU0OCIsImlhdCI6MTUyNTkwMTE1MCwiZXhwIjoxNTI1OTg3NTUwLCJzdWIiOiJBZG1pbiIsInN1Ijp0cnVlfQ.b423Npg_eJ8kf7bwYo4kryYSlGfleBzMA66fEYJsZII';
//return $su_token;

require (__DIR__.'/JWT/JWT.php');
use \Firebase\JWT\JWT;

$key = 'NT3EnryyUM1hcdlPtAQ+sBW3RWc9whKFDAVnCQHv6y4=';
$token = array(
  "instance"=> "85c702df-adf4-4049-8b98-2937a3a106e0",
  "iss"=> "api_keys/59f2caf6-4112-4e68-9484-cbe78a882e48",
  "iat" => time(),
//  "exp" => time()+24*60*60-1,
  "exp" => time()+30*60-1,
  "sub"=> "Admin",
  "su" => true
);
/**
 * IMPORTANT:
 * You must specify supported algorithms for your application. See
 * https://tools.ietf.org/html/draft-ietf-jose-json-web-algorithms-40
 * for a list of spec-compliant algorithms.
 */
$jwt = JWT::encode($token, $key);
//$decoded = JWT::decode($jwt, $key, array('HS256'));

return $jwt;

?> 