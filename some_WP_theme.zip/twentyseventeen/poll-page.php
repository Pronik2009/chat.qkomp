<?php
/*
Template Name: PollNew
*/

//get_header(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat template</title>
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/plugins/slick/slick.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/plugins/slick/slick-theme.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/plugins/sweetalert/sweetalert.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/animate.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/c4c/css/style.css" rel="stylesheet">
	<style>
		.chat-discussion {padding:5px;}
		.chat-message {padding:2px 5px;}
		.chat-discussion .chat-message.left .message {margin-left:0px;margin-right:55px;background:#fff;}
		.chat-discussion .chat-message.right .message {margin-left:55px;margin-right:0px;background: #f6f6f6;}
		.chat-discussion .chat-message.money .message {margin-left:55px;margin-right:55px;background: #ffd1fe; border:1px solid #ff00f9;}
		.chat-discussion .chat-message.money .message-date { float: right; }
		.chat-discussion .chat-message.money .message-author,
		.chat-discussion .chat-message.money .message-content { color:#222; }
		.message-author {color: #555;font-weight:bold;}
		.message-author i {font-weight:normal;}
		
		.slick-slider{margin-bottom:10px;padding-left:0;}
		.slick-slide {padding:5px;background:#FFFFFF;cursor:pointer;}
		.slick-slide span {display:block;position:absolute;top:7px;}
		.slick-slide p {display:none;}
		.slick-slide img {margin:0 auto;border-radius:2px;}
		.slick-slide.active {background:#D9EDF7;}
		.slick-slide .label-danger {background:#c823c5;}
		
		.autor_info .label-danger {background:#c823c5;}
		.donate-block{margin-bottom:10px;}
	</style>
</head>

<body class="gray-bg">

	<!--  HEADER -->
	<div class="row violet-bg border-bottom">
		<div class="col-lg-12 text-center"><h1 style="margin:10px auto;"><i class="fa fa-comments"></i> LiveChat</h1></div>
	</div>
<?php
  
//Get event_id from GET url
  if (!empty($_GET)) {
    $event_id=array_keys($_GET)[0];
    if (strlen($event_id)==32){ ; } else {die('URL error');};
    $sql="SELECT IF(EXISTS(SELECT * FROM wp_posts WHERE MD5(ID)='".$event_id."' and ping_status='open'),1,0)";
    if($wpdb->get_var($sql)){//echo 'Welcome to registration!';
    }
    else { die('Event error');};
    } else { die('Parameters error');};

    $sql="SELECT costs FROM wp_c4c_guests WHERE id=".$_COOKIE['uid'];
    $guest_amount = $wpdb->get_var($sql);//echo 'Welcome to registration!';

//Check user Cookies
  if (!isset($_COOKIE['event_'.$event_id])) {
    //echo $event_id;  
    include('c4c/guest_registration.php');exit;
  };
  $guest_name=$_COOKIE['event_'.$event_id];
  $guest_id=$_COOKIE['uid'];
  $room_id = $_COOKIE['room_id'];
?>
      <?php include('c4c/poll.php'); ?>
<?php //get_footer(); ?>